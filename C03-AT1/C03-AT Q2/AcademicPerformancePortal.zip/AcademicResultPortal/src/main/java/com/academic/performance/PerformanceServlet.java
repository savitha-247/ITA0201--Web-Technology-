package com.academic.performance;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/PerformanceServlet")
public class PerformanceServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        PrintWriter out = response.getWriter();

        // Request-specific local variables
        String name = request.getParameter("name");
        String register = request.getParameter("register");
        String mark1Text = request.getParameter("mark1");
        String mark2Text = request.getParameter("mark2");
        String mark3Text = request.getParameter("mark3");

        // Validate missing values
        if (name == null || name.trim().isEmpty()
                || register == null || register.trim().isEmpty()
                || mark1Text == null || mark1Text.trim().isEmpty()
                || mark2Text == null || mark2Text.trim().isEmpty()
                || mark3Text == null || mark3Text.trim().isEmpty()) {

            showError(out,
                    "Missing Information",
                    "Please enter the student name, register number and all three marks.");

            return;
        }

        try {

            // Convert marks into integers
            int mark1 = Integer.parseInt(mark1Text);
            int mark2 = Integer.parseInt(mark2Text);
            int mark3 = Integer.parseInt(mark3Text);

            // Validate marks
            if (mark1 < 0 || mark1 > 100
                    || mark2 < 0 || mark2 > 100
                    || mark3 < 0 || mark3 > 100) {

                showError(out,
                        "Invalid Marks",
                        "All subject marks must be between 0 and 100.");

                return;
            }

            // Calculations
            int total = mark1 + mark2 + mark3;

            double average = total / 3.0;

            int highest = Math.max(mark1,
                    Math.max(mark2, mark3));

            // Pass / Fail
            String result;

            if (mark1 >= 40 && mark2 >= 40 && mark3 >= 40) {
                result = "PASS";
            } else {
                result = "FAIL";
            }

            // Dynamic HTML result
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");

            out.println("<meta charset='UTF-8'>");
            out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");

            out.println("<title>Acadexa Result</title>");

            out.println("<style>");

            out.println("*{");
            out.println("margin:0;");
            out.println("padding:0;");
            out.println("box-sizing:border-box;");
            out.println("font-family:'Segoe UI',Arial,sans-serif;");
            out.println("}");

            out.println("body{");
            out.println("min-height:100vh;");
            out.println("background:");
            out.println("radial-gradient(circle at 15% 15%,rgba(99,102,241,.20),transparent 28%),");
            out.println("radial-gradient(circle at 85% 85%,rgba(20,184,166,.16),transparent 30%),");
            out.println("#080b18;");
            out.println("display:flex;");
            out.println("justify-content:center;");
            out.println("align-items:center;");
            out.println("padding:25px;");
            out.println("color:white;");
            out.println("}");

            out.println(".card{");
            out.println("width:850px;");
            out.println("max-width:100%;");
            out.println("background:#11162b;");
            out.println("border:1px solid #292f4b;");
            out.println("border-radius:28px;");
            out.println("padding:38px;");
            out.println("box-shadow:0 30px 80px rgba(0,0,0,.45);");
            out.println("}");

            out.println(".top{text-align:center;margin-bottom:30px;}");

            out.println(".tag{");
            out.println("display:inline-block;");
            out.println("padding:8px 15px;");
            out.println("border-radius:30px;");
            out.println("background:#102b2c;");
            out.println("border:1px solid #245050;");
            out.println("color:#4de1d1;");
            out.println("font-size:9px;");
            out.println("font-weight:900;");
            out.println("letter-spacing:1.5px;");
            out.println("}");

            out.println("h1{");
            out.println("margin-top:14px;");
            out.println("font-size:34px;");
            out.println("}");

            out.println(".subtitle{");
            out.println("margin-top:8px;");
            out.println("color:#858faa;");
            out.println("font-size:12px;");
            out.println("}");

            out.println(".student{");
            out.println("display:grid;");
            out.println("grid-template-columns:1fr 1fr;");
            out.println("gap:15px;");
            out.println("margin-bottom:18px;");
            out.println("}");

            out.println(".info{");
            out.println("padding:18px;");
            out.println("background:#171d36;");
            out.println("border:1px solid #29304c;");
            out.println("border-radius:15px;");
            out.println("}");

            out.println(".info span{");
            out.println("display:block;");
            out.println("font-size:9px;");
            out.println("font-weight:800;");
            out.println("letter-spacing:1.2px;");
            out.println("color:#7f89a8;");
            out.println("margin-bottom:7px;");
            out.println("}");

            out.println(".info strong{");
            out.println("font-size:15px;");
            out.println("color:#f0f2fa;");
            out.println("}");

            out.println(".marks{");
            out.println("display:grid;");
            out.println("grid-template-columns:repeat(3,1fr);");
            out.println("gap:15px;");
            out.println("}");

            out.println(".mark{");
            out.println("text-align:center;");
            out.println("padding:22px;");
            out.println("background:linear-gradient(145deg,#171d38,#0d1226);");
            out.println("border:1px solid #29304c;");
            out.println("border-radius:17px;");
            out.println("}");

            out.println(".mark span{");
            out.println("display:block;");
            out.println("font-size:9px;");
            out.println("color:#7f89a8;");
            out.println("letter-spacing:1px;");
            out.println("margin-bottom:9px;");
            out.println("}");

            out.println(".mark b{");
            out.println("font-size:29px;");
            out.println("color:#4de1d1;");
            out.println("}");

            out.println(".summary{");
            out.println("display:grid;");
            out.println("grid-template-columns:repeat(3,1fr);");
            out.println("gap:15px;");
            out.println("margin-top:18px;");
            out.println("}");

            out.println(".summary-box{");
            out.println("padding:20px;");
            out.println("text-align:center;");
            out.println("background:#6366f1;");
            out.println("border-radius:17px;");
            out.println("}");

            out.println(".summary-box span{");
            out.println("display:block;");
            out.println("font-size:9px;");
            out.println("letter-spacing:1px;");
            out.println("margin-bottom:8px;");
            out.println("opacity:.8;");
            out.println("}");

            out.println(".summary-box strong{");
            out.println("font-size:21px;");
            out.println("}");

            out.println(".pass{");
            out.println("margin-top:20px;");
            out.println("padding:18px;");
            out.println("text-align:center;");
            out.println("border-radius:15px;");
            out.println("background:#10352f;");
            out.println("border:1px solid #216b5e;");
            out.println("color:#55e3c8;");
            out.println("font-size:18px;");
            out.println("font-weight:900;");
            out.println("}");

            out.println(".fail{");
            out.println("margin-top:20px;");
            out.println("padding:18px;");
            out.println("text-align:center;");
            out.println("border-radius:15px;");
            out.println("background:#391b25;");
            out.println("border:1px solid #733040;");
            out.println("color:#ff8294;");
            out.println("font-size:18px;");
            out.println("font-weight:900;");
            out.println("}");

            out.println(".back{");
            out.println("display:block;");
            out.println("text-align:center;");
            out.println("margin-top:25px;");
            out.println("color:#4de1d1;");
            out.println("text-decoration:none;");
            out.println("font-size:12px;");
            out.println("font-weight:800;");
            out.println("}");

            out.println("@media(max-width:650px){");
            out.println(".student,.marks,.summary{grid-template-columns:1fr;}");
            out.println(".card{padding:25px;}");
            out.println("}");

            out.println("</style>");
            out.println("</head>");

            out.println("<body>");

            out.println("<div class='card'>");

            out.println("<div class='top'>");
            out.println("<span class='tag'>ACADEXA • OFFICIAL RESULT</span>");
            out.println("<h1>Academic Performance</h1>");
            out.println("<div class='subtitle'>Result dynamically generated by Java Servlet</div>");
            out.println("</div>");

            // Student details
            out.println("<div class='student'>");

            out.println("<div class='info'>");
            out.println("<span>STUDENT NAME</span>");
            out.println("<strong>" + escape(name) + "</strong>");
            out.println("</div>");

            out.println("<div class='info'>");
            out.println("<span>REGISTER NUMBER</span>");
            out.println("<strong>" + escape(register) + "</strong>");
            out.println("</div>");

            out.println("</div>");

            // Marks
            out.println("<div class='marks'>");

            out.println("<div class='mark'>");
            out.println("<span>SUBJECT 01</span>");
            out.println("<b>" + mark1 + "</b>");
            out.println("</div>");

            out.println("<div class='mark'>");
            out.println("<span>SUBJECT 02</span>");
            out.println("<b>" + mark2 + "</b>");
            out.println("</div>");

            out.println("<div class='mark'>");
            out.println("<span>SUBJECT 03</span>");
            out.println("<b>" + mark3 + "</b>");
            out.println("</div>");

            out.println("</div>");

            // Summary
            out.println("<div class='summary'>");

            out.println("<div class='summary-box'>");
            out.println("<span>TOTAL</span>");
            out.println("<strong>" + total + " / 300</strong>");
            out.println("</div>");

            out.println("<div class='summary-box'>");
            out.println("<span>AVERAGE</span>");
            out.println("<strong>" + String.format("%.2f", average) + "</strong>");
            out.println("</div>");

            out.println("<div class='summary-box'>");
            out.println("<span>HIGHEST</span>");
            out.println("<strong>" + highest + "</strong>");
            out.println("</div>");

            out.println("</div>");

            // Result
            if (result.equals("PASS")) {

                out.println("<div class='pass'>");
                out.println("✓ RESULT STATUS : PASS");
                out.println("</div>");

            } else {

                out.println("<div class='fail'>");
                out.println("✕ RESULT STATUS : FAIL");
                out.println("</div>");
            }

            out.println("<a class='back' href='index.html'>");
            out.println("← Process Another Student");
            out.println("</a>");

            out.println("</div>");

            out.println("</body>");
            out.println("</html>");

        } catch (NumberFormatException e) {

            showError(out,
                    "Invalid Mark Format",
                    "Please enter numbers only for all three subject marks.");
        }
    }

    private void showError(PrintWriter out,
                           String title,
                           String message) {

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");

        out.println("<meta charset='UTF-8'>");
        out.println("<title>Acadexa Error</title>");

        out.println("<style>");

        out.println("body{");
        out.println("margin:0;");
        out.println("min-height:100vh;");
        out.println("background:#080b18;");
        out.println("display:flex;");
        out.println("justify-content:center;");
        out.println("align-items:center;");
        out.println("font-family:Segoe UI,Arial,sans-serif;");
        out.println("color:white;");
        out.println("}");

        out.println(".error{");
        out.println("width:500px;");
        out.println("max-width:90%;");
        out.println("padding:40px;");
        out.println("background:#11162b;");
        out.println("border:1px solid #343b58;");
        out.println("border-radius:25px;");
        out.println("text-align:center;");
        out.println("box-shadow:0 30px 70px rgba(0,0,0,.45);");
        out.println("}");

        out.println(".icon{");
        out.println("font-size:45px;");
        out.println("color:#ff9b67;");
        out.println("}");

        out.println("h1{color:white;}");

        out.println("p{");
        out.println("color:#929bb7;");
        out.println("line-height:1.7;");
        out.println("}");

        out.println("a{");
        out.println("display:inline-block;");
        out.println("margin-top:15px;");
        out.println("color:#4de1d1;");
        out.println("font-weight:800;");
        out.println("text-decoration:none;");
        out.println("}");

        out.println("</style>");
        out.println("</head>");

        out.println("<body>");

        out.println("<div class='error'>");

        out.println("<div class='icon'>⚠</div>");

        out.println("<h1>" + title + "</h1>");

        out.println("<p>" + message + "</p>");

        out.println("<a href='index.html'>← Return to Portal</a>");

        out.println("</div>");

        out.println("</body>");
        out.println("</html>");
    }

    private String escape(String value) {

        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}